<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>Vitoriawagen!</title>
  <link rel="icon" type="imagem/png" href="imagens/logovw.png" />

  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <script type="text/javascript" src="js/jquery.min.js"></script>
  <!--<script type="text/javascript" src="js/jquery.mask.js"></script>-->
  <script type="text/javascript" src="js/functions.js"></script>

</head>
<body>

<!--IMAGEM ANTES DO MENU-->
<div class="row">
  <div class="col-12 divMenu">  
  </div>
</div>

<!--MENU-->
<nav class="navbar navbar-expand-lg navbar-dark menu" id="navPrincipal" >
  <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active" class="cor colorMenu">
        <a class="nav-link" href="#" onclick="visibilidadePolo()">Novo Polo</a>
      </li>
      <li class="nav-item active" class="corUp colorMenu">
        <a class="nav-link" href="#" onclick="visibilidadeUp()">Up!</a>
      </li>
    </ul>
  </div>
</nav>

<!--CONTEÚDO DA PÁGINA-->
<div id="divConteudo">

  <p aline="center">Mensagem enviada com sucesso.</p>

</div>


<!-- FOOTER -->
<footer class="page-footer font-small indigo">
  
  <!--INFORMAÇÕES DO PRODUTO VENDIDO POLO-->
  <div class="blueLight" id="divPoloRodape">
    <p id="msgVenda">Imagens ilustrativas. Novo Polo 1.0 MPI - prata - a partir de R$ 49.990,00 - condição de taxa 0% válida exclusivamente para modelos 1.0 MPI e 1.6 MSI com entrada de 90% e saldo em 12 meses. Promoção valida até 28/02/2018 ou enquanto durar o estoque.</p>
  </div>

  <!--INFORMAÇÕES DO PRODUTO VENDIDO UP-->
  <div class="blueLight" id="divUPRodape">
    <p id="msgVenda">Imagens ilustrativas. Novo UP 1.0 MPI - vermelho - a partir de R$ 49.990,00 - condição de taxa 0% válida exclusivamente para modelos 1.0 MPI e 1.6 MSI com entrada de 90% e saldo em 12 meses. Promoção valida até 28/02/2018 ou enquanto durar o estoque.</p>
  </div>

  <hr id="divisao">

  <!--LOGOMARCA-->
  <div class="centerFooter">
    <img alt="Logo Vitoriawagen" src="imagens/rodape.png">
  </div>
  <br>

  <!--UNIDADES-->
  <div class="endFooter">
    <div class="row">
      <div class="col"></div>
      <div class="col-1 selMuni"><b>Vitória</b></div>
      <div class="col-1"><b>Serra</b></div>
      <div class="col"></div>
    </div>
    <br>

    <!--INFORMAÇÕES DE CONTATO-->
    <div>
      <i class="fa fa-map-marker"></i>
      <label>Av. Vitória, 1047 - Romão - Vitória - Cep 29041-405</label>
    </div>
    <div>
      <i class="fa fa-envelope-square"></i>
      <label>E-mail: vitoriawagen@grupolider.com.br</label>
    </div>
    <div>
      <i class="fa fa-phone-square"></i>
      <label>tel (27) 3331-8100</label>
    </div>

    <!--LINKS PARA REDES SOCOAIS-->
    <a class="mr-4 link" href="https://pt-br.facebook.com/Vitoriawagen"><i class="fa fa-facebook-f fa-2x"></i></a>
    <a class="link" href="https://www.instagram.com/vitoriawagen/?hl=pt-br"><i class="fa fa-instagram fa-2x"></i></a>
    <br><br>
  </div>
</footer>
</body>
</html>


<?php 
function redirecionar($url, $tempo) { 
   $url = str_replace('&;', '&', $url); 
   if($tempo > 3) { 
      header("Refresh: $tempo; URL=$url"); 
   } else { 
      header("Location: index.php"); 
      exit; 
    } 
}
redirecionar('index.php', 5); // Redireciona depois de 5 seg 
?>
