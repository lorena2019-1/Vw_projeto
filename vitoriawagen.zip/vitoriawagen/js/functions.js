/**Assim que a página é carregada, chama essa função*/
$(document).ready(function() {
    $('#divPolo').show(); // Mostra a imagem e tabela de preço do Novo Polo!
    $('#divUp').hide(); //Oculta a imagem e tabela de preço do UP!
    $('#divPoloRodape').show(); // Mostra os dados do rodapé referente ao Novo Polo!
    $('#divUPRodape').hide(); //Oculta os dados do rodapé referentes ao UP!
    $('#modelCar').val() = "Novo Polo";
    $('.cor').addClass('.colorMenu');
    $('.corUp').removeClass('.colorMenu');
});

/**Quando se clica no menu "Novo Polo" mostra os dados do polo e oculta os do UP */
function visibilidadePolo() {
    $('#divPolo').show(); // Mostra a imagem e tabela de preço do Novo Polo!
    $('#divUp').hide(); //Oculta a imagem e tabela de preço do UP!
    $('#divPoloRodape').show(); // Mostra os dados do rodapé referente ao Novo Polo!
    $('#divUPRodape').hide(); //Oculta os dados do rodapé referentes ao UP!
    $('#modelCar').val() = "Novo Polo";
    $('.cor').addClass('.colorMenu');
    $('.corUp').removeClass('.colorMenu');
    
}

/**Quando se clica no menu "UP!" mostra os dados do UP e oculta os do Novo Polo */
function visibilidadeUp() {
    $('#divPolo').hide(); //Oculta a imagem e tabela de preço do Novo Polo
    $('#divUp').show(); // Mostra a imagem e tabela de preço do UP!
    $('#divPoloRodape').hide(); //Oculta os dados do rodapé referentes ao Novo Polo
    $('#divUPRodape').show(); // Mostra os dados do rodapé referente ao UP!
    $('#modelCar').val() = "Up";
    $('.corUp').addClass('.colorMenu');
    $('.cor').removeClass('.colorMenu');
}

//Valida e-mail usando Regex

function validaFormulario() {
    //Captura o formulario de cadastro
    var $formCadastro = document.querySelector('#formCadastro');

    // Variável de controle para saber se o formulário será enviado ou não
    var envio = true;

    //Valida se o campo nome é diferente de vazio
    if ($('#nome').val() == "") {
        envio = false;
        alert("O campo Nome é de preenchimento obrigatório!");
        return false;
    }

    //Valida se o campo e-mail é diferente de vazio
    if ($('#email').val() == "") {
        envio = false;
        alert("O campo E-mail é de preenchimento obrigatório!");
        return false;
    }
    
    //Valida se o campo telefone é diferente de vazio
    if ($('#telefone').val() == "") {
        envio = false;
        alert("O campo Telefone é de preenchimento obrigatório!");
        return false;
    }

    //Valida se o campo mensagem é diferente de vazio
    if ($('#mensagem').val().length < 10) {
        envio = false;
        alert("O campo Mensagem deve ter no mínimo 10 caracteres!");
        return false;
    }
 
    //Se não cair em nenhuma das exceções acima, o formulario é enviado
    if (envio == true) {
        $formCadastro.submit();
    }

}



