
<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>Vitoriawagen!</title>
  <link rel="icon" type="imagem/png" href="imagens/logovw.png" />

  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <script type="text/javascript" src="js/jquery.min.js"></script>
  <!--<script type="text/javascript" src="js/jquery.mask.js"></script>-->
  <script type="text/javascript" src="js/functions.js"></script>

</head>
<body>

<!--IMAGEM ANTES DO MENU-->
<div class="row">
  <div class="col-12 divMenu">  
  </div>
</div>

<!--MENU-->
<nav class="navbar navbar-expand-lg navbar-dark menu" id="navPrincipal" >
  <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active" class="cor colorMenu">
        <a class="nav-link" href="#" onclick="visibilidadePolo()">Novo Polo</a>
      </li>
      <li class="nav-item active" class="corUp colorMenu">
        <a class="nav-link" href="#" onclick="visibilidadeUp()">Up!</a>
      </li>
    </ul>
  </div>
</nav>

<!--CONTEÚDO DA PÁGINA-->
<div id="divConteudo">
  <div class="row">
    <!--LADO ESQUERDO POLO-->
      <div class="col-6" id="divPolo">
        <div class="row">
          <div class="col"></div>
          <div class="col tabelaPreco">
            <p class="info"><b>NOVO POLO</b> <br>
            1.0 MPI</p>
          </div>
          <div class="col-auto tabelaPreco linha-vertical">
            <p class="info">A PARTIR DE <b>R$49.990,00</b><br>+ TAXA <b>0%</b> </p>
          </div>
          <div class="col"></div>
        </div>

      <img src="imagens/novo-polo.png">
      </div>

    <!--LADO ESQUERDO UP-->
      <div class="col-6" id="divUp">
          <div class="row">
            <div class="col"></div>
            <div class="col tabelaPreco">
              <p class="info"><b>NOVO UP!</b> <br>
              1.0 MPI</p>
            </div>
            <div class="col-auto tabelaPreco linha-vertical">
              <p class="info">A PARTIR DE <b>R$49.990,00</b><br>+ TAXA <b>0%</b> </p>
            </div>
            <div class="col"></div>
          </div>

          <img src="imagens/take-up-vermelho.png">
        </div>

    

    <!--LADO DIREITO-->
    <div class="col-6">
      <h4 class="info"><b>SAIA NA FRENTE E GARANTA SEU VOLKSWAGEN</b></h4>
      <p class="info">Escolha o modelo que você deseja e receba ofertas imperdíveis em primeira mão.</p>
      <form id="formCadastro" method="POST" action="bd.php">
        <div class="row formCad">
          <div class="col">
            <input type="text" placeholder="Nome" class="form-control" name="nome" id="nome" required />
            <input type="email" placeholder="E-mail" class="form-control" name="email" id="email"  required/>
            <input type="text" placeholder="(00) 0000-0000 ou (00) 00000-0000" class="form-control phone-ddd-mask"  name="telefone" id="telefone"  required/>
            <input type="hidden" name="modelCar" id="modelCar" value=""/>
            <input type="hidden" name="acao" id="acao" value="salvar"/>
          </div>
          <div class="col">
            <textarea  placeholder="Mensagem" class="form-control" name="mensagem" id="mensagem" minlength="10" required></textarea>
            <button class="btn btn-success garanta" id="salvar" name="salvar" onclick="validaFormulario()">GARANTA AGORA</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>


<!-- FOOTER -->
<footer class="page-footer font-small indigo">
  
  <!--INFORMAÇÕES DO PRODUTO VENDIDO POLO-->
  <div class="blueLight" id="divPoloRodape">
    <p id="msgVenda">Imagens ilustrativas. Novo Polo 1.0 MPI - prata - a partir de R$ 49.990,00 - condição de taxa 0% válida exclusivamente para modelos 1.0 MPI e 1.6 MSI com entrada de 90% e saldo em 12 meses. Promoção valida até 28/02/2018 ou enquanto durar o estoque.</p>
  </div>

  <!--INFORMAÇÕES DO PRODUTO VENDIDO UP-->
  <div class="blueLight" id="divUPRodape">
    <p id="msgVenda">Imagens ilustrativas. Novo UP 1.0 MPI - vermelho - a partir de R$ 49.990,00 - condição de taxa 0% válida exclusivamente para modelos 1.0 MPI e 1.6 MSI com entrada de 90% e saldo em 12 meses. Promoção valida até 28/02/2018 ou enquanto durar o estoque.</p>
  </div>

  <hr id="divisao">

  <!--LOGOMARCA-->
  <div class="centerFooter">
    <img alt="Logo Vitoriawagen" src="imagens/rodape.png">
  </div>
  <br>

  <!--UNIDADES-->
  <div class="endFooter">
    <div class="row">
      <div class="col"></div>
      <div class="col-1 selMuni"><b>Vitória</b></div>
      <div class="col-1"><b>Serra</b></div>
      <div class="col"></div>
    </div>
    <br>

    <!--INFORMAÇÕES DE CONTATO-->
    <div>
      <i class="fa fa-map-marker"></i>
      <label>Av. Vitória, 1047 - Romão - Vitória - Cep 29041-405</label>
    </div>
    <div>
      <i class="fa fa-envelope-square"></i>
      <label>E-mail: vitoriawagen@grupolider.com.br</label>
    </div>
    <div>
      <i class="fa fa-phone-square"></i>
      <label>tel (27) 3331-8100</label>
    </div>

    <!--LINKS PARA REDES SOCOAIS-->
    <a class="mr-4 link" href="https://pt-br.facebook.com/Vitoriawagen"><i class="fa fa-facebook-f fa-2x"></i></a>
    <a class="link" href="https://www.instagram.com/vitoriawagen/?hl=pt-br"><i class="fa fa-instagram fa-2x"></i></a>
    <br><br>
  </div>
</footer>
</body>
</html>
