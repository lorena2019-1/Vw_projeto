<?php

require_once("conexao.php");

$nome= $_POST['nome'];
$email= $_POST['email'];
$telefone= $_POST['telefone'];
$mensagem= $_POST['mensagem'];

// Valida o e-mail
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: javascript:history.back(1)");
}
// Valida o telefone(xx){xxxx ou xxxxx}xxxx
if(!preg_match('^\(+[0-9]{2,3}\)[0-9]{4,5}-[0-9]{4}$^', $telefone)){
    header("Location: javascript:history.back(1)");
    } 

$sql = "INSERT INTO cadastro (nome, email, telefone, mensagem) VALUES ('$nome', '$email', '$telefone', '$mensagem')"; 
$result = $mysqli->query($sql);

if(!$result){
    $var = "<script>javascript:history.back(-2)</script>";
echo $var;
}else{
  header("Location: resposta.php");
}

?>

